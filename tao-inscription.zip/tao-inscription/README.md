# tao-inscription

Based on the tao-inscription Protocol, Bittensor Data Parsing and Persistence

* Please note, these steps require the Go language version 1.21 or above.

1、Download the project to your local machine, modify the configuration files to suit your own settings(`./config/resources/config.toml`), and then run `go install` to install dependencies.

2、Run the `go build main.go` to create an executable file.

3、Run the `go run main` to start the service.